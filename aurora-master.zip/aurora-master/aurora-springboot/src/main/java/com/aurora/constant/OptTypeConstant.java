package com.aurora.constant;

public interface OptTypeConstant {

    String SAVE_OR_UPDATE = "新增或修改";

    String SAVE = "新增";

    String UPDATE = "修改";

    String DELETE = "删除";

    String UPLOAD = "上传";

    String EXPORT = "导出";

}
