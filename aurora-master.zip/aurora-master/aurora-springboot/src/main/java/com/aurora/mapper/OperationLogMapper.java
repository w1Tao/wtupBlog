package com.aurora.mapper;

import com.aurora.entity.OperationLog;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.springframework.stereotype.Repository;

@Repository
public interface OperationLogMapper extends BaseMapper<OperationLog> {

}
