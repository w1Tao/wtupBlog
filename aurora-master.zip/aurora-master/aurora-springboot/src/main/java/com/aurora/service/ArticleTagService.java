package com.aurora.service;

import com.aurora.entity.ArticleTag;
import com.baomidou.mybatisplus.extension.service.IService;

public interface ArticleTagService extends IService<ArticleTag> {

}
