package com.aurora.service;

import com.aurora.entity.UserRole;
import com.baomidou.mybatisplus.extension.service.IService;

public interface UserRoleService extends IService<UserRole> {

}
