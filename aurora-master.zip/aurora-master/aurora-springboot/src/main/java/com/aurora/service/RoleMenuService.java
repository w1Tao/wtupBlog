package com.aurora.service;

import com.aurora.entity.RoleMenu;
import com.baomidou.mybatisplus.extension.service.IService;

public interface RoleMenuService extends IService<RoleMenu> {

}
