package com.aurora.mapper;

import com.aurora.entity.About;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.springframework.stereotype.Repository;

@Repository
public interface AboutMapper extends BaseMapper<About> {

}
