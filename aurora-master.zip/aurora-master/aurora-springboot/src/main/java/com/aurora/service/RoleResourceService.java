package com.aurora.service;

import com.aurora.entity.RoleResource;
import com.baomidou.mybatisplus.extension.service.IService;

public interface RoleResourceService extends IService<RoleResource> {

}
