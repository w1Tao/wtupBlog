package com.aurora.mapper;

import com.aurora.entity.Photo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.springframework.stereotype.Repository;

@Repository
public interface PhotoMapper extends BaseMapper<Photo> {

}
