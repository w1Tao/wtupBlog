package com.aurora.constant;

public interface SocialLoginConstant {

    String QQ_OPEN_ID = "openid";

    String ACCESS_TOKEN = "access_token";

    String OAUTH_CONSUMER_KEY = "oauth_consumer_key";

}
