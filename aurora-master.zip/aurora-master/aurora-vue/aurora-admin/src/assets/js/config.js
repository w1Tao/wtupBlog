export default {
  UPLOAD_SIZE: 200
}
